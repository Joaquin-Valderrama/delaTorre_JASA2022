%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% script_simuation_SCLSDec.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script compares different criteria and implementations for least
% squares (LS) deconvolution: 
%     * conventional LS deconvolution (LS), 
%     * LS deconv. transformed to the reduced representation space (LS-R)
%     * and subspace-constrained LS deconv. (SC-LS)
% The criteria are implemented with matrix division (RSLSD) and with
% iterative estimation (IRSA).
% The execution of this script requires the following functions:
%      Basis_LinLog_RRC.m   Provides the transformation V for the subspace
%      IRSA_LS.m            IRSA (iterative) implementation of LS 
%      IRSA_LSR.m           IRSA (iterative) implementation of LS-R
%      IRSA_SCLS.m          IRSA (iterative) implementation of SC-LS
%      RSLSD_LS.m           RSLSD (matrix div.) implementation of LS 
%      RSLSD_LSR.m          RSLSD (matrix div.) implementation of LS-R
%      RSLSD_SCLS.m         RSLSD (matrix div.) implementation of SC-LS
% And additionally, a response used for the simulation
%      response_30_60_subj1.mat
% A noisy EEG is synthesized from the reference response according to the 
% script configuration; the different deconvolution methods are compared. 
% It requires signal processing toolbox
% For Octave users, run:    pkg load signal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear,clc; 

%% Configuration parameters for simulation
fs=14700;          % sampling rate 14700 Hz
NOISE_GAIN=4;      % noise level
%J=round(1000e-3*fs);   % length of the response 14700, for 1 second
J=round(500e-3*fs);    % length of the response: 7350 for 500 ms
isi_min=30e-3; % 30 ms
isi_max=60e-3; % 60 ms
%n_stim=15200;  % number of stimuli 15200
n_stim=500;    % number of stimuli 500
OUTPUT_IRSA=0; % flag for reporing algorithm evolution
CONVERG_CRITERION=120; % convergence criterion for IRSA_matrix_fft_fast, 120 dB
Imax=10000;    % maximum number of iterations for IRSA
Kdec=40;       % resolution of the LDFDS transformation (samples/decade)
V=Basis_LinLog_RRC(J,Kdec); % LDFDS transformation for subspace

%% Stimulation sequence
isi=rand(n_stim,1)*(isi_max-isi_min)+isi_min; % random distribution of isi, uniform
stim_ind = round(cumsum(isi)*fs); % indexes of stimulus start
N=max(stim_ind)+fs; % number of samples
s=zeros(N,1);
s(stim_ind)=1;

%% Response to be used in simulation (response to be estimated)
load('response_30_60_subj1.mat');
x(J+1)=0; x=x(1:J); % this guarantees a response length equal to J
x=V'*(V*x); % LDFDS applied to x to remove components out of the subspace
t_plot=(0:(J-1))/fs;
figure(1)
semilogx(t_plot*1000,x); xlabel('time (ms)'); ylabel('amplitude');
title('Response to be estimated (time log-scaled)'); 
grid on; xlim([0.1 1000*J/fs]);
figure(2)
plot(t_plot*1000,x); xlabel('time (ms)'); ylabel('amplitude');
title('Response to be estimated (time in linear scale)'); 
grid on; xlim([0 1000*J/fs]);

%% Simulation of EEG: y=s*x+noise
y0=filter(x,1,s);
y=y0+randn(size(y0))*std(y0)*NOISE_GAIN;
SNR_EEG=10*log10(var(y0)/var(y-y0));
figure(3)
t_plotN=(0:(N-1))/fs;
figure(3)
plot(t_plotN,y); xlabel('time (s)'); ylabel('amplitude'); 
title(sprintf('EEG     (SNR-EEG: %.2f dB)',SNR_EEG))
figure(4)
plot(t_plotN,y); xlim([0 1])
xlabel('time (s)'); ylabel('amplitude'); 
title(sprintf('EEG (first second)     (SNR-EEG: %.2f dB)',SNR_EEG))

%% Deconvolution (with predefined alpha and number of iterations)
fprintf('Running RSLSD_LS....\n')
[x1,t_run1]    = RSLSD_LS(y,stim_ind,J);
fprintf('Running IRSA_LS....\n')
[x2,t_run2]    = IRSA_LS(y,stim_ind,Imax,CONVERG_CRITERION,J,OUTPUT_IRSA);
fprintf('Running RSLSD_LSR....\n')
[x3,t_run3]    = RSLSD_LSR(y,stim_ind,V);
fprintf('Running IRSA_LSR....\n')
[x4,t_run4]    = IRSA_LSR(y,stim_ind,V,Imax,CONVERG_CRITERION,OUTPUT_IRSA);
fprintf('Running RSLSD_SCLS....\n')
[x5,t_run5]    = RSLSD_SCLS(y,stim_ind,V);
fprintf('Running IRSA_SCLS....\n')
[x6,t_run6]    = IRSA_SCLS(y,stim_ind,V,Imax,CONVERG_CRITERION,OUTPUT_IRSA);
fprintf('\n--------END OF IRSA/RSLSD ALGORITHMS---------------\n\n')

%% Results: figure
figure(5)
x3=V'*x3; x4=V'*x4; x5=V'*x5; x6=V'*x6; % transformed to original representation
semilogx(t_plot*1000,[x+3.5 x6+2.5 x5+2 x4+1.5 x3+1 x2+0.5 x1 ]); 
xlabel('time (ms)'); ylabel('amplitude');
title('Estimated responses');
legend('Response (ref.)','SC-LS iter.','SC-LS mat.div.', ...
    'LS-R iter.','LS-R mat.div.','LS iter.','LS mat.div.');
legend('Location','eastoutside');
grid on; xlim([0.2 1000*J/fs]);

%% Results: difference among responses
% SNR using the clean response as reference
SNR1_a=10*log10(var(x)/var(x1-x)); SNR2_a=10*log10(var(x)/var(x2-x));
SNR3_a=10*log10(var(x)/var(x3-x)); SNR4_a=10*log10(var(x)/var(x4-x));
SNR5_a=10*log10(var(x)/var(x5-x)); SNR6_a=10*log10(var(x)/var(x6-x));
% SNR using SC-LS mat.div. (RSLSD_SCLS) as reference
SNR1_b=10*log10(var(x6)/var(x1-x6)); SNR2_b=10*log10(var(x6)/var(x2-x6));
SNR3_b=10*log10(var(x6)/var(x3-x6)); SNR4_b=10*log10(var(x6)/var(x4-x6));
SNR5_b=10*log10(var(x6)/var(x5-x6)); 
fprintf('SNR of estimated responses, using the clean response as reference:\n')
fprintf('  SC-LS iter.:      %.5f dB\t\t  SC-LS mat.div.:   %.5f dB\n',SNR6_a,SNR5_a)  
fprintf('  LS-R iter.:       %.5f dB\t\t  LS-R mat.div.:    %.5f dB\n',SNR4_a,SNR3_a)  
fprintf('  LS iter.:         %.5f dB\t\t  LS mat.div.:      %.5f dB\n',SNR2_a,SNR1_a)  
fprintf('SNR of estimated responses, using SC-LS iter. as reference:\n')
fprintf('  SC-LS mat.div.:   %.5f dB\n',SNR5_b)  
fprintf('  LS-R iter.:       %.5f dB\t\t  LS-R mat.div.:    %.5f dB\n',SNR4_b,SNR3_b)  
fprintf('  LS iter.:         %.5f dB\t\t  LS mat.div.:      %.5f dB\n',SNR2_b,SNR1_b)  
fprintf('Total execution time:\n')
fprintf('  SC-LS iter.:      %.5f s\t\t  SC-LS mat.div.:   %.5f s\n',t_run6,t_run5)  
fprintf('  LS-R iter.:       %.5f s\t\t  LS-R mat.div.:    %.5f s\n',t_run4,t_run3)  
fprintf('  LS iter.:         %.5f s\t\t  LS mat.div.:      %.5f s\n',t_run2,t_run1)  

return
