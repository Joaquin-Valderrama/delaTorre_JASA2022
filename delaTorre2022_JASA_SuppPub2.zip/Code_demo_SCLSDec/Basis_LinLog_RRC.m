%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [V] = Basis_LinLog_RRC(J,Kdec)     (revised Nov-2019)
%
% Basis_LinLog_RRC() constructs an orthonormal basis of functions (V),
% uniformly distributed in the lin-log-scaled time, with one function
% per sample at small latency and Kdec functions per decade at large
% latency.
% Root-raised-cosine (RRC) function is used for each element of the basis. 
% This function is used in digital communications because it provides
% an appropriate limitation of the bandwidth with a relatively short
% duration in the impulsive response.
% The resulting functions are orthonormalized with Gram-Schmidt.
% The resulting basis is contained in a [J_red,J] matrix, with J_red<J.
% The matrix V contains J_red rows, each one with a vector of J components.
% The application of the basis V to a function x (V*x) provides a
% representation in a reduced representation space. The application of the
% transpose V' to the reduced representation (V'*(V*x)) provides a
% reconstruction from the reduced representation into the original time
% representation that is equivalent to a latency-dependent low-pass
% filtering of the response.
%
% INPUT:  [J]      Number of samples in the original representation
%         [Kdec]   Number of functions per decade
% OUTPUT: [V]      Orthonormal basis of functions provided as a matrix
%
% Example: V = Basis_LinLog_RRC(500,25);
%
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama (2019)
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [V] = Basis_LinLog_RRC(J,Kdec)
%%%% Check for correct input of data
if(J<40||J<Kdec||Kdec<5||Kdec>500) 
    error('Error: V=Basis_LinLog_RRC(J,Kdec); (J>=40,J>=Kdec,5<=Kdec<=500)')
end
%%%% Initialization of variables
j=0:(J-1);           % Time-axis, linear scale (in samples)
jr_samp=Kdec*log10(j*log(10)/Kdec+1);  % Time-axis, compressed scale 
jr=0:(jr_samp(end)-1); % Samples in compressed scale (functions in basis)
K=length(jr);        % K: Number of functions of the base
%%%% Function template: raised cosine function
Npt_sym=40;           % number of points per symbol period in raised-cosine
N_per=14.6;           % number of periods to each side of the raised-cosine
alpha=0.20;           % roll-off factor (low-pass filtering effect)
[h,tau]=sr_rcos(Npt_sym,N_per,alpha);
%%%% Set of functions of the base before amplitude normalization (V0)
V0 = zeros(length(jr),length(j)); % V0: K functions with J*5 samples
for k=1:K
    % Functions are placed at jr(k) latency (linearly distr in compr. scale)
    V0(k,:)=interp1(tau,h,jr(k)-jr_samp,'linear',0);
end
%%%% Gram-Schmidt orthonormalization
V=OrthoNorm_Gauss_fast(V0,K);
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [h,tau] = sr_rcos(Npt_sym,n_per,alpha)
%
% This function prepares the samples of a square root raised cosine filter
%  See Proakis, J. (1995). Digital Communications. McGraw-Hill Inc. or
%  https://en.wikipedia.org/wiki/Root-raised-cosine_filter)
% Proakis and wikipedia formulas are identical except for a factor Ts
% In this implementation Ts=1;
% Input parameters:
%   Npt_sym samples per symbol (or symbol period expressed in samples) 
%   n_per   number of periods to the left and to the right of maximum
%   alpha   roll off factor (between 0 and 1)
% output:
%   h       impulsive response
%   tau     normalized time, t/Ts
% example: 
%   [h,tau]=sr_rcos(20,6,0.35)
function [h,tau] = sr_rcos(Npt_sym,N_per,alpha)
if alpha == 0, alpha = realmin; end
tau = (-N_per:1/Npt_sym:N_per); h=zeros(size(tau));
% (A) response for t=0:
cond1=tau==0;
h(cond1)=1+alpha*(4/pi-1);
% (B) response for denominator=0:
denom0=1-(4.*alpha.*tau).^2;
cond2=abs(denom0) < sqrt(eps);
phi=pi/(4*alpha);
h(cond2)=alpha/(sqrt(2))*( (1+2/pi)*sin(phi) + (1-2/pi)*cos(phi) );
% (C) response for all the other samples:
cond3=~(cond2|cond1);
t1=tau(cond3);
phi1=pi*t1*(1-alpha); phi2=pi*t1*(1+alpha);
denom=pi*t1.*denom0(cond3);
h(cond3)=(sin(phi1) + 4*alpha*t1.*cos(phi2))./(denom);
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% V=OrthoNorm_Gauss_fast(V0,K)
% Orthonormalization, Gauss Method (fast implementation)
% Input parameters:
%    V0  matrix with vectors to be orthonormalized
%    K   number of vectors
% Output paramter:
%    V   matrix with orthonormalized vectors
function V=OrthoNorm_Gauss_fast(V0,K)
% prenormalization
for k=1:K,  v=V0(k,:); V0(k,:)=v/sqrt(dot(v,v)); end;
P=V0*V0';       % Gaussian elimination of [V0*V0' | V] = [P | V0]
M_all=eye(K);   % Matrix operations to be applied to P for Gaussian elimination
for j1=1:K-1
    M_tmp=eye(K);
    for j2=(j1+1):K
        M_tmp(j2,j1)=-P(j2,j1); M_tmp(j2,j2)=P(j1,j1);
        P(j2,:)=P(j2,:)*P(j1,j1)-P(j1,:)*P(j2,j1);
    end
    M_all=M_tmp*M_all;
    M_tmp=eye(K);
    M_tmp(j1+1,j1+1)=1/P(j1+1,j1+1);
    M_all=M_tmp*M_all;
    P(j1+1,:)=P(j1+1,:)/P(j1+1,j1+1);
end
V=M_all*V0;    % Matrix operations applied to V0
% Final normalization
for k=1:K, v=V(k,:);  v=v/sqrt(dot(v,v));  V(k,:)=v;  end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%