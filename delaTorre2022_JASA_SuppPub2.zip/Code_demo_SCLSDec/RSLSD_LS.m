%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi ,t_run] = RSLSD_LS(y,m,J)
% Randomized Stimulation with Least Squares Deconvolution: direct
% deconvolution (infinite iterations) with matrix inversion
%     xi =  Rs^(-1) z0         xi = Rs\z0;
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     J (Length of the averaging window in samples)
%  Output parameters: xi (AEP estimate)
%                     t_run (time required for algorithm execution)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2021
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi ,t_run] = RSLSD_LS(y,m,J)
% Initialization
tic;                 % time-stamp beginning of function
N=length(y);
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0_int=int32(zeros(J,1)); rs0_int=uint32(zeros(J,1));
s(N,1) = uint8(0); m=cast(m,'uint32'); s(m)=1;  % stimulation signal
gain=1e6/max(abs(y));
y1=int32(y*gain);
for j=1:J
    idx=j+m-1;
    z0_int(j)=sum(y1(idx));  % cross-corr between EEG and stim. signal
    rs0_int(j)=sum(s(idx));  % autocorrelation of stim. signal
end
z0=double(z0_int)/Es/gain;   % first averaged response
rs0=double(rs0_int)/Es;      % normalized autocorrelation stim. signal
Rs=zeros(J,J);
for i=1:J
    j=1:J; idx=abs(j-i)+1;
    Rs(i,j)=rs0(idx); % autocorrelation matrix
end
xi=(Rs\z0);           % direct deconvolution by matrix inversion
t_run=toc;            % total execution time
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%