%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi ,t_run,t_iter,Niter,alpha] = IRSA_LS(y,m,I,SNR,J,OUTPUT)
% IRSA, matrix implementation with matrix product in fft domain
%    (this is possible because Rs is a Toeplitz-symmetric matrix)
%    Fast version: alpha / converg. criterion optimized (120dB num. error)
%  Input parameters:  y (Recorded EEG)
%                    m (Trigger vector)
%                    I (maximum number of iterations)
%                    SNR (SNR for numerical error in convergence criterion)
%                    J (Length of the averaging window in samples)
%                    OUTPUT (flag for presenting results at iterations)
%  Output parameters: xi (AEP estimate)
%                    t_run (time required for algorithm execution)
%                    t_iter (time required for each iteration)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2021
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi ,t_run,t_iter,Niter,alpha] = IRSA_LS(y,m,I,SNR,J,OUTPUT)
% Initialization
tic;                 % time-stamp beginning of function
N=length(y);
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0_int=int32(zeros(J,1)); rs0_int=uint32(zeros(J,1));
s(N,1) = uint8(0); m=cast(m,'uint32'); s(m)=1;  % stimulation signal
gain=1e6/max(abs(y));
y1=int32(y*gain);
for j=1:J
    idx=j+m-1;
    z0_int(j)=sum(y1(idx));  % cross-corr between EEG and stim. signal
    rs0_int(j)=sum(s(idx));  % autocorrelation of stim. signal
end
z0=double(z0_int)/Es/gain;   % first averaged response
rs0=double(rs0_int)/Es;      % normalized autocorrelation stim. signal
RS=real(fft([rs0; 0; flipud(rs0(2:end))]));       % FT of autocorrelation
Z0=fft([z0; zeros(J,1)]); Zi=Z0; Xi=zeros(2*J,1); % FT of z0, zi and xi
lambda_1=max(RS(1:2:J)); lambda_2=max(RS(2:2:J));
max_mu=0.5*(lambda_1+lambda_2); % bound for max eigenvalue of autoc. matrix
alpha=1.9/max_mu;        % selected alpha (close to maximum value)
ener_z0=Z0'*Z0;          % energy of RSA solution used for convergence
thr_conv=10^(-SNR/20);   % threshold for convergence criterion
% Iterations
t_iter=toc;          % time-stamp for iterations
for i=1:I            % loop for iterations
    Xi=Xi+alpha*Zi;    % AEP estimate in freq. domain
    P=RS.*Xi;          % matrix product in freq. domain
    P1=real(ifft(P));  % this two lines are important in order to truncate 
    P=fft([P1(1:J); zeros(J,1)]); % the estimation of the P in time domain
    Zi=Z0-P;    
    ener_zi=Zi'*Zi;              % energy of the correction at current it.
    ratio=sqrt(ener_zi/ener_z0); % ratio of correction vs initialization
    if ratio<thr_conv, break; end; % convergence criterion (loop broken)  
    if OUTPUT==1, fprintf('It.%d: ratio:%.16f alpha=%.5f\n',i,ratio,alpha); end;
end
Niter=i;
xi=real(ifft(Xi));    % the result is transformed to time domain
xi=xi(1:J);           % ...and truncated to remove the non-causal part
t_run=toc;               % total execution time
t_iter=(t_run-t_iter)/i; % execution time for each iteration
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
