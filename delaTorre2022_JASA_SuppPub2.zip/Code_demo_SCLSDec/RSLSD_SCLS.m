%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi_ssp ,t_run] = RSLSD_SCLS(y,m,V)
% Randomized Stimulation with Least Squares Deconvolution 
% Subspace Constrained version (fast implementation)
% Direct deconvolution with matrix inversion
%     Rs_ssp = V Rs V'    z0_ssp = V z0
%     xi_ssp =  Rs_ssp^(-1) z0_ssp         xi_ssp = Rs_ssp\z0_ssp;
%  Input parameters:  y (Recorded EEG)
%                     m (Trigger vector)
%                     V (Transformation matrix, Jred x J components)
%  Output parameters: xi_ssp (AEP estimate in the subspace representation)
%                     t_run (time required for algorithm execution)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2021
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi_ssp ,t_run] = RSLSD_SCLS(y,m,V)
% Initialization
tic;                 % time-stamp beginning of function
[Jred,J]=size(V);    % dimensions of the representation space and subspace
N=length(y);
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0_int=int32(zeros(J,1)); rs0_int=uint32(zeros(J,1));
s(N,1) = uint8(0); m=cast(m,'uint32'); s(m)=1;  % stimulation signal
gain=1e6/max(abs(y));
y1=int32(y*gain);
for j=1:J
    idx=j+m-1;
    z0_int(j)=sum(y1(idx));  % cross-corr between EEG and stim. signal
    rs0_int(j)=sum(s(idx));  % autocorrelation of stim. signal
end
z0=double(z0_int)/Es/gain;   % first averaged response
rs0=double(rs0_int)/Es;      % normalized autocorrelation stim. signal
rs0ext=[flipud(rs0(2:end)); rs0]; % extended autocorrelation
% Estimation of the matrix to be inverted Rs_ssp
Aux=zeros(J,Jred);
for i=1:Jred
    a=conv(V(i,:),rs0ext,'same');
    Aux(:,i)=a';
end
Rs_ssp=V*(Aux);
% Subspace constrained deconvolution
z0_ssp=V*z0;
xi_ssp=(Rs_ssp\z0_ssp);
t_run=toc;            % total execution time
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%