%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [xi_ssp ,t_run, t_iter] = IRSA_SCLS(y,m,V,I,SNR,OUTPUT)
% IRSA, matrix implementation
%    Fast version: alpha / converg. criterion optimized (120dB num. error)
%    Subspace Constrained version: 
%    Subspace version of Rs and z0 used in the recursion
%     Rs_ssp = V Rs V'    z0_ssp = V z0
%  Input parameters: y (Recorded EEG)
%                    m (Trigger vector)
%                    V (Transformation matrix, Jred x J components)
%                    I (maximum number of iterations)
%                    SNR (SNR for numerical error in convergence criterion)
%                    OUTPUT (flag for presenting results at iterations)
%  Output parameters: xi_ssp (AEP estimate in the subspace representation)
%                     t_run (time required for algorithm execution)
%                     t_iter (time required for each iteration)
% Angel de la Torre, Jose Carlos Segura, Joaquin Valderrama 2021
%     University of Granada (Spain) 
%     National Acoustic Laboratories, Macquarie University (Australia)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xi_ssp ,t_run, t_iter, Niter, alpha] = IRSA_SCLS(y,m,V,I,SNR,OUTPUT)
% Initialization
tic;                 % time-stamp beginning of function
[Jred,J]=size(V);    % dimensions of the representation space and subspace
N=length(y);
Es=length(m);        % energy of the stimulation signal (number of stimuli)
z0_int=int32(zeros(J,1)); rs0_int=uint32(zeros(J,1));
s(N,1) = uint8(0); m=cast(m,'uint32'); s(m)=1;  % stimulation signal
gain=1e6/max(abs(y));
y1=int32(y*gain);
for j=1:J
    idx=j+m-1;
    z0_int(j)=sum(y1(idx));  % cross-corr between EEG and stim. signal
    rs0_int(j)=sum(s(idx));  % autocorrelation of stim. signal
end
z0=double(z0_int)/Es/gain;        % first averaged response
rs0=double(rs0_int)/Es;           % normalized autocorrelation stim. signal
rs0ext=[flipud(rs0(2:end)); rs0]; % extended autocorrelation
% estimation of eigenvalues of Rs and convergence parameter alpha
RS=real(fft([rs0; 0; flipud(rs0(2:end))]));       % FT of autocorrelation
lambda_1=max(RS(1:2:J)); lambda_2=max(RS(2:2:J));
max_mu=0.5*(lambda_1+lambda_2); % bound for max eigenvalue of autoc. matrix
alpha=1.9/max_mu;        % selected alpha (close to maximum value)
% Estimation of the matrix to be inverted Rs_ssp
Aux=zeros(J,Jred);
for i=1:Jred
    a=conv(V(i,:),rs0ext,'same');
    Aux(:,i)=a';
end
Rs_ssp=V*(Aux);
% Subspace constrained deconvolution
z0_ssp=V*z0;
ener_z0=z0_ssp'*z0_ssp;  % energy of RSA solution used for convergence
thr_conv=10^(-SNR/20);   % threshold for convergence criterion
% Iterations
xi=zeros(Jred,1);     % initial estimation of the response
zi=z0_ssp;
t_iter=toc;          % time-stamp for iterations
for i=1:I            % loop for iterations
    xi=xi+alpha*zi;  % AEP estimate
    zi=z0_ssp-Rs_ssp*xi; % Average residual estimation
    ener_zi=zi'*zi;  % energy of the correction at current iteration
    ratio=sqrt(ener_zi/ener_z0); % ratio of correction vs initialization
    if ratio<thr_conv, break; end; % convergence criterion (loop broken)
    if OUTPUT==1
        fprintf('It.%d: ratio:%.16f alpha=%.5f\n',i,ratio,alpha); 
    end
end
Niter=i;
xi_ssp=xi;
t_run=toc;               % total execution time
t_iter=(t_run-t_iter)/i; % execution time for each iteration
return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%